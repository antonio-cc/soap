<?php
// How to Create a SOAP Client/Server in PHP - Part 01
// https://www.youtube.com/watch?v=e_7jDqN2A-Y

class client {
    public function __construct() {
        $params = array('location' => 'http://localhost/soap-server/server1.php',
            'uri' => 'urn://localhost/soap-server/server1.php',
            'trace' => 1);
        $this->instance = new SoapClient(null, $params);
    }

    public function getName($id_array) {
        // https://www.php.net/manual/en/soapclient.soapcall.php --> wrap the array arguments in another array 
        return $this->instance->__soapCall('getStudentName', array($id_array));
        //return $this->instance->getStudentName($id_array);
    }
}

$client = new client();
