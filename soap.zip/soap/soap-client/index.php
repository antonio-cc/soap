<!doctype html>
<html lang="en">
<head>
    <title>Consume a SOAP Service with PHP</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<h1>Consume a SOAP Service with PHP</h1>
<ul>
    <li><a href="service1.php">service1.php</a></li>
    <li><a href="service2.php">service2.php</a></li>
    <li><a href="service2.php?id=2">service2.php?id=2</a></li>
    <li><a href="service2_session.php">service2_session.php</a></li>
    <li><a href="service2_ajax_xhttp.php">service2_ajax_xhttp.php</a></li>
    <li><a href="service2_ajax_jquery.php">service2_ajax_jquery.php</a></li>
    <li><a href="service2_fetch.php">service2_fetch.php</a></li>
</ul>
</body>
</html>