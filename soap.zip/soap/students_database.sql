-- soap-auth example database

-- mysql -u root -p < students_database.sql

CREATE DATABASE IF NOT EXISTS students;

CREATE TABLE IF NOT EXISTS students.students (
  id int unsigned PRIMARY KEY,
  name varchar(15) NOT NULL
);

DELETE FROM students.students;

INSERT INTO students.students (id, name) VALUES
(1, 'Ana'),
(2, 'Diana'),
(3, 'Triana');

-- Create user

CREATE USER IF NOT EXISTS 'students'@'localhost' IDENTIFIED BY 'students';

GRANT ALL ON `students`.* TO 'students'@'localhost';
